document.addEventListener("DOMContentLoaded", () => {
  const button = document.querySelector("button");
  
  button.addEventListener("click", () => {
    const colors = ["#ffcc00", "#00ccff", "#ff6699", "#99ff99"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    document.body.style.backgroundColor = randomColor;
  });
});

document.getElementById("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");
});

document.querySelectorAll(".enroll").forEach((btn) => {
  btn.addEventListener("click", () => {
    const selectedCourse = btn.getAttribute("data-course");

    document.querySelector("select").value = selectedCourse;

    document.getElementById("contact").scrollIntoView({
      behavior: "smooth",
    });
  });
});

document.getElementById("enrollForm").addEventListener("submit", function (e) {
  e.preventDefault();
  document.getElementById("formMsg").innerText =
    "Enrollment Successful ✅ We will contact you soon!";
});
document.getElementById("enrollForm").addEventListener("submit", function (e) {
  e.preventDefault(); 
  document.getElementById("formMsg").innerText = "✅ Registration Successful!";
  this.reset();
});
